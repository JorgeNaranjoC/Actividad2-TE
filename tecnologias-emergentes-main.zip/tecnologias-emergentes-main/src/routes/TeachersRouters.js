import { lazy } from 'react';
import Loadable from 'components/Loadable';
import MainLayout from 'layout/MainLayout/index';
import { element } from 'prop-types';

const Teachers = Loadable(lazy(() => import('pages/teachers')));
const Create = Loadable(lazy(() => import('pages/teachers/create')));

const TeachersRouters = {
  path: '/',
  element: <MainLayout />,
  children: [
    {
      path: 'teachers',
      element: <Teachers />
    },
    {
      path: 'teachers/create',
      element: <Create />
    }
  ]
};

export default TeachersRouters;
