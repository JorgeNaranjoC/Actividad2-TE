import { lazy } from 'react';
import Loadable from 'components/Loadable';
import MainLayout from 'layout/MainLayout/index';
import { element } from 'prop-types';

const Students = Loadable(lazy(() => import('pages/students')));
const Create = Loadable(lazy(() => import('pages/students/create')));

const StudentsRouters = {
  path: '/',
  element: <MainLayout />,
  children: [
    {
      path: 'students',
      element: <Students />
    },
    {
      path: 'students/create',
      element: <Create />
    }
  ]
};

export default StudentsRouters;
