// assets
import { SolutionOutlined } from '@ant-design/icons';

// icons
const icons = {
  SolutionOutlined
};

// ==============================|| MENU ITEMS - UTILITIES ||============================== //

const teachers = {
  id: 'teachers',
  title: 'Teachers',
  type: 'group',
  children: [
    {
      id: 'teachers',
      title: 'Teachers', // titulo de como se vera en el menu
      type: 'item',
      url: '/teachers', // hacia donde se dirige el menu
      icon: icons.SolutionOutlined // icono
    }
  ]
};

export default teachers;
