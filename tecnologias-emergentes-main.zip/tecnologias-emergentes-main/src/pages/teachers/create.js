import TeachersForm from './components/teachersForm';

const Create = () => {
  return <TeachersForm />;
};

export default Create;
