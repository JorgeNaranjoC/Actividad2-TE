import PropTypes from 'prop-types';
// material-ui
import {
  Typography,
  Stack,
  LinearProgress,
  Grid,
  TextField,
  MenuItem,
  Button,
  Select,
  RadioGroup,
  FormControlLabel,
  FormLabel,
  Radio
} from '@mui/material';

// project import
import MainCard from 'components/MainCard';

// react-router-dom
import { Link } from 'react-router-dom';

const TeachersForm = ({ teacher, isEdit }) => {
  if (!teacher && isEdit) {
    return <LinearProgress />;
  }

  return (
    <Stack spacing={3} px={20}>
      <MainCard>
        <Grid container spacing={3}>
          <Grid item xs={6} sm={4} md={6} lg={4}>
            <Typography variant="h5" fontWeight="bold">
              DATOS DEL PROFESOR
            </Typography>
          </Grid>
          <Grid item xs={6} sm={4} md={6} lg={8}>
            <Stack spacing={2}>
              <TextField id="outlined-basic" label="Nombre" variant="outlined" defaultValue={teacher.name} />
              <TextField id="outlined-basic" label="Apellido" variant="outlined" defaultValue={teacher.lastName} />
              <TextField id="outlined-basic" label="Email" variant="outlined" defaultValue={teacher.email} />
              <TextField id="outlined-basic" label="Telefono" variant="outlined" defaultValue={teacher.phone} />
              <TextField id="outlined-basic" label="Direccion" variant="outlined" defaultValue={teacher.address} />
              <TextField id="outlined-basic" label="Area" variant="outlined" defaultValue={teacher.area} />
              <Select labelId="demo-simple-select-label" defaultValue={teacher.typeDocument} id="demo-simple-select" label="Type Document">
                <MenuItem value="passport">Pasaporte</MenuItem>
                <MenuItem value="identification_card">Cedula</MenuItem>
                <MenuItem value="identification_card">Tarjeta de Identidad</MenuItem>
              </Select>
              <TextField id="outlined-basic" label="Identificacion" variant="outlined" defaultValue={teacher.id} />
              <FormLabel id="demo-simple-select-label">Fecha de Cumpleaños</FormLabel>
              <TextField id="outlined-basic" type="date" variant="outlined" placeholder="YY/MM/AAA" defaultValue={teacher.dateBirth} />
              <Select labelId="demo-simple-select-label" defaultValue={teacher.typeDocument} id="demo-simple-select" label="Type Document">
                <MenuItem value="passport">Seleccione la Materia</MenuItem>
                <MenuItem value="identification_card">Tecnologias Emergentes</MenuItem>
                <MenuItem value="identification_card">Base de Datos</MenuItem>
                <MenuItem value="identification_card">Matemticas</MenuItem>
                <MenuItem value="identification_card">Contabilidad</MenuItem>
              </Select>
            </Stack>
          </Grid>
        </Grid>
      </MainCard>

      <Stack>
        <Grid container spacing={2} direction="row-reverse">
          <Grid item>
            <Button size="small" variant="contained">
              CREAR
            </Button>
          </Grid>

          <Grid item>
            <Button size="small" variant="outlined" component={Link} to="/teachers">
              CANCELAR
            </Button>
          </Grid>
        </Grid>
      </Stack>
    </Stack>
  );
};

TeachersForm.propTypes = {
  teacher: PropTypes.object,
  isEdit: PropTypes.bool
};

const Teacher = {
  name: '',
  lastName: '',
  email: '',
  phone: '',
  address: '',
  age: 0,
  id: '',
  pasport: '',
  gender: 'male',
  typeDocument: 'passport',
  typeSubject: 'machine_learning',
  numberDocument: '',
  dateBirth: ''
};

TeachersForm.defaultProps = {
  teacher: Teacher,
  isEdit: false
};

export default TeachersForm;
