import StudentForm from './components/studentForm';

const Create = () => {
  return <StudentForm />;
};

export default Create;
